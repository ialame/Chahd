# Refonte Chahd — Direction C · fichiers prêts à l'emploi

Ces fichiers remplacent ceux de votre dépôt, **en conservant l'arborescence**.
Copiez chaque fichier à l'emplacement correspondant sous `frontend/`.

| Fichier ici | À copier vers (dans `frontend/`) |
|-------------|----------------------------------|
| `tailwind.config.ts`        | `frontend/tailwind.config.ts` |
| `nuxt.config.ts`            | `frontend/nuxt.config.ts` |
| `assets/css/main.css`       | `frontend/assets/css/main.css` |
| `layouts/default.vue`       | `frontend/layouts/default.vue` |
| `pages/index.vue`           | `frontend/pages/index.vue` |
| `components/MatiereCard.vue`| `frontend/components/MatiereCard.vue` |

## Mise en route

```bash
# de préférence sur une branche dédiée
git checkout -b refonte-design

# … copier les fichiers ci-dessus …

cd frontend
npm run dev
```

## Ce qui change

- **Couleur de marque** : teal → bordeaux `#8a3324` (+ `ink/paper/rule/theo`).
- **Polices** : Spectral (titres) + IBM Plex Sans (corps).
- **Coins** quasi droits (radius 2px), suppression des dégradés et ombres.
- **Hero** d'accueil sans dégradé, sommaire numéroté (I–IV), monogrammes ∑ / PC / SVT.
- **Boîtes pédagogiques** : Définition en bordeaux, Théorème en vert `#4a7340`.

## Reste à faire (extraits dans REFONTE-DIRECTION-C.md)

Les pages suivantes n'ont que des retouches mineures (couleurs/emoji), détaillées dans
`REFONTE-DIRECTION-C.md` — pas de fichier complet fourni ici :
`annales/index.vue`, `tableau-de-bord.vue`, `planning/index.vue`,
`connexion.vue`, `inscription.vue`, `reviser.vue`,
`components/FlashcardViewer.vue`, `components/QuizRunner.vue`.

> Astuce : la plupart se résument à remplacer `text-brand-dark` → `text-brand`,
> `bg-slate-*` → `bg-paper`/`bg-rule`, les grands chiffres en `font-serif`,
> et les emoji par les monogrammes.
